//////////
//THANKS//
//////////

Hi there, this is Will from unTied Games! Nice to meet you.

Super huge THANK YOU for downloading this asset... It means a lot to me that you've chosen it for your game!
If you use this asset in your game, give me a shoutout if you can at @untiedgames, so I can follow along on your development journey!
Want to follow me? Sign up for my newsletter! Or follow me using the Twitter / FB / Youtube links below.
Newsletter signup: http://untiedgames.com/signup

Did you know? You can get access to ALL of my assets if you support me on Patreon!
Check it out: http://patreon.com/untiedgames

MORE LINKS:
Browse my other assets: untiedgames.itch.io/
Watch me make pixel art, games, and more: youtube.com/c/unTiedGamesTV
Follow on Facebook: facebook.com/untiedgames
Follow on Twitter: twitter.com/untiedgames
Visit my blog: untiedgames.com

Thanks again,
- Will

///////////////////
//VERSION HISTORY//
///////////////////

Version 1.0 (10/31/21)
	- Initial release. Happy Halloween!

/////////////////////////
//HOW TO USE THIS ASSET//
/////////////////////////

Hello! Thank you for downloading the Mimic Chest asset pack. Here are a few pointers to help you navigate and make sense of this zip file.

- In the root folder, you will find folders corresponding to each color style for the character.

- In any of the style folders, you will find a folder named PNG. This folder contains folders of individual PNGs representing each animation for that character in that style.

- In the style folders, you will also find a folder named spritesheet. This folder contains the spritesheet for the character animations in the corresponding color style as well as a metadata file for parsing the spritesheet.

- Recommended animation FPS: 15

Any questions?
Email me at contact@untiedgames.com and I'll try to answer as best I can!

-Will