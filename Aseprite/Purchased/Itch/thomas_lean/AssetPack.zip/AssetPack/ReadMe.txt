Hello and welcome on this asset pack!

Thanks a lot for the purchase!! 
I really hope you'll enjoy making games with this cute character :)



Thanks again and have fun!
(Thanks to Elder Teck for the extra-exports, I'm sure it'll help some of you)


Thomas Lean

