//////////
//THANKS//
//////////

Hi there, this is Will from unTied Games! Nice to meet you.

Super huge THANK YOU for downloading this asset... It means a lot to me that you've chosen it for your game!
If you use this asset in your game, give me a shoutout if you can at @untiedgames, so I can follow along on your development journey!
Want to follow me? Sign up for my newsletter! Or follow me using the Twitter / FB / Youtube links below.
Newsletter signup: http://untiedgames.com/signup

Did you know? You can get access to ALL of my assets if you support me on Patreon!
Check it out: http://patreon.com/untiedgames

MORE LINKS:
Browse my other assets: untiedgames.itch.io/
Watch me make pixel art, games, and more: youtube.com/c/unTiedGamesTV
Follow on Facebook: facebook.com/untiedgames
Follow on Twitter: twitter.com/untiedgames
Visit my blog: untiedgames.com

Thanks again,
- Will

///////////////////
//VERSION HISTORY//
///////////////////

Version 1.0 (10/28/22)
	- Initial release. Woohoo!

/////////////////////////
//HOW TO USE THIS ASSET//
/////////////////////////

Hello! Thank you for downloading the Super Pixel Alien Monster Pack 1 asset pack. Here are a few pointers to help you navigate and make sense of this zip file.

- In the root folder, you will find folders named PNG and spritesheet.

- The PNG folder contains all the characters separated into their own folders by color theme. In each one of those folders, the character animations are separated into their own subfolders, with the frames as individual PNG files.

- The spritesheet folder contains all the effect animations separated into their own folders, but with the frames packed into a single image. A metadata file is alongside each spritesheet which may be used to parse the image.

- Recommended animation FPS: 15 (66.7 ms/frame)

- Tip: You can use the splatter effects in multiple ways!
	- As an impact animation to indicate an enemy is damaged by an attack
	- As an impact animation when an enemy's attack projectile hits something
	- As a death animation for the enemies

Any questions?
Email me at contact@untiedgames.com and I'll try to answer as best I can!

-Will